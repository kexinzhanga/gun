import OBR from '@owlbear-rodeo/sdk';
import {CHANNEL,SETTINGS,TOOL,MODE} from './core';
import {fire,readState} from './api';
import {play,startEngine,enable} from './engine';
const icon=new URL('./icon.svg',location.href).href;
OBR.onReady(async()=>{
 startEngine();enable(readState().enabled);
 window.addEventListener('storage',event=>{if(event.key===SETTINGS)enable(readState().enabled);});
 const rates=new Map<string,number>();
 OBR.broadcast.onMessage(CHANNEL,event=>{
  const now=performance.now();if(now-(rates.get(event.connectionId)??-1000)<250)return;
  rates.set(event.connectionId,now);if(rates.size>100)rates.delete(rates.keys().next().value!);
  void play(event.data).catch(console.error);
 });
 let previousTool:string|undefined;
 await OBR.tool.create({id:TOOL,icons:[{icon,label:'枪火：点击目标开火'}],defaultMode:MODE,
 onClick:async context=>{if(context.activeTool!==TOOL)previousTool=context.activeTool;}});
 await OBR.tool.createMode({id:MODE,icons:[{icon,label:'点击目标开火',filter:{activeTools:[TOOL]}}],
 cursors:[{cursor:'crosshair'}],preventDrag:{},
 onToolClick:async(_context,event)=>{
  try {const target=event.target?.type==='IMAGE'&&event.target.layer==='CHARACTER'?event.target.id:undefined;await fire(event.pointerPosition,target);}
  catch(error){await OBR.notification.show(error instanceof Error?error.message:'开火失败','ERROR');}
  return true;
 },onKeyDown:(_context,event)=>{if(event.key==='Escape'&&previousTool)void OBR.tool.activateTool(previousTool);}});
 const ownConnection=await OBR.player.getConnectionId();
 OBR.broadcast.onMessage(SETTINGS,event=>{
  if(event.connectionId!==ownConnection)return;
  const data=event.data as {previousTool?:string;cancel?:boolean};
  if(data?.previousTool&&data.previousTool!==TOOL)previousTool=data.previousTool;
  if(data?.cancel&&previousTool)void OBR.tool.activateTool(previousTool);
 });
});
