import OBR from '@owlbear-rodeo/sdk';
import {config,NS,SETTINGS,TOOL,type Weapon,type Config} from './core';
import {readState,writeState,fire} from './api';
import './style.css';
const $=<T extends HTMLElement=HTMLElement>(id:string)=>document.getElementById(id) as T;
const status=$('status');let connected=false;
let state=readState();
let presets:Record<string,Config>={};
try{const raw=JSON.parse(localStorage.getItem(NS+'/presets')||'{}');for(const [name,value] of Object.entries(raw).slice(0,30))presets[name]=config(value);}catch{/* empty presets */}
function report(error:unknown){status.textContent=error instanceof Error?error.message:String(error);}
function persist(){try{writeState(state);}catch(error){report(error);}}
function draw(){
 $('shooter').textContent=state.shooter?`射手：${state.name||'未命名角色'}`:'尚未锁定射手';
 for(const key of ['result','color','burst','thickness','spread','speed','muzzle'] as const)($<HTMLInputElement>(key)).value=String(state.settings[key]);
 $<HTMLInputElement>('enabled').checked=state.enabled;
 document.querySelectorAll<HTMLButtonElement>('[data-weapon]').forEach(button=>{button.classList.toggle('active',button.dataset.weapon===state.settings.weapon);button.setAttribute('aria-pressed',String(button.dataset.weapon===state.settings.weapon));});
}
function renderPresets(){const select=$<HTMLSelectElement>('presets');select.replaceChildren(new Option('选择已保存预设',''));for(const name of Object.keys(presets))select.add(new Option(name,name));}
function bind(id:string,fn:()=>Promise<void>){$(id).addEventListener('click',()=>void fn().catch(report));}
for(const key of ['result','color','burst','thickness','spread','speed','muzzle'] as const)$(key).addEventListener('change',()=>{
 const input=$<HTMLInputElement>(key);state.settings=config({...state.settings,[key]:key==='result'||key==='color'?input.value:Number(input.value)});persist();draw();
});
document.querySelectorAll<HTMLButtonElement>('[data-weapon]').forEach(button=>button.addEventListener('click',()=>{
 const weapon=button.dataset.weapon as Weapon;
 const defaults:Record<Weapon,Partial<Config>>={pistol:{burst:1,spread:10,speed:1800,color:'#ffc266'},rifle:{burst:3,spread:18,speed:2200,color:'#ffc266'},shotgun:{burst:1,spread:70,speed:1600,color:'#ffc266'},energy:{burst:1,spread:4,speed:3000,color:'#48dfff',thickness:4},rpg:{burst:1,spread:10,speed:700,color:'#ff9a3d',thickness:4}};
 state.settings=config({...state.settings,weapon,...defaults[weapon]});persist();draw();
}));
bind('lock',async()=>{
 if(!connected||!await OBR.scene.isReady())throw Error('请在 Owlbear 房间里打开场景。');
 const ids=await OBR.player.getSelection()??[];
 if(ids.length!==1)throw Error('请只选中一个角色 Token。');
 const [token]=await OBR.scene.items.getItems(ids);
 if(token.type!=='IMAGE'||token.layer!=='CHARACTER')throw Error('射手必须是角色层的图像 Token。');
 state.shooter=token.id;state.name=token.name;persist();draw();status.textContent='已锁定射手。现在可以选择目标开火。';
});
bind('aim',async()=>{
 if(!connected)throw Error('请在 Owlbear 房间内使用。');
 if(!state.shooter)throw Error('请先设置射手。');
 const previousTool=await OBR.tool.getActiveTool();
 await OBR.broadcast.sendMessage(SETTINGS,{previousTool},{destination:'LOCAL'});
 await OBR.tool.activateTool(TOOL);status.textContent='瞄准中：点击目标 Token 或地图位置开火。按 Esc 退出。';
});
bind('fire',async()=>{
 if(!connected)throw Error('请在 Owlbear 房间内使用。');
 const ids=await OBR.player.getSelection()??[];if(ids.length!==1)throw Error('请只选中一个目标。');
 await fire({x:0,y:0},ids[0]);status.textContent='已开火。';
});
bind('cancel',async()=>{if(connected){await OBR.broadcast.sendMessage(SETTINGS,{cancel:true},{destination:'LOCAL'});status.textContent='已退出瞄准，可切回右侧选择工具。';}});
bind('savePreset',async()=>{
 const name=$<HTMLInputElement>('presetName').value.trim();if(!name)throw Error('请输入预设名称。');
 if(!Object.hasOwn(presets,name)&&Object.keys(presets).length>=30)throw Error('最多保存 30 个预设。');
 presets={...presets,[name]:{...state.settings}};localStorage.setItem(NS+'/presets',JSON.stringify(presets));renderPresets();status.textContent='预设已保存。';
});
bind('deletePreset',async()=>{const name=$<HTMLSelectElement>('presets').value;if(!name)return;delete presets[name];localStorage.setItem(NS+'/presets',JSON.stringify(presets));renderPresets();});
 $('presets').addEventListener('change',()=>{const name=$<HTMLSelectElement>('presets').value;if(Object.hasOwn(presets,name)){state.settings=config(presets[name]);persist();draw();}});
 $('enabled').addEventListener('change',()=>{state.enabled=$<HTMLInputElement>('enabled').checked;persist();});
draw();renderPresets();
if(OBR.isAvailable)OBR.onReady(()=>{connected=true;status.textContent='就绪：选中角色，然后设为射手。';});
else {status.textContent='界面预览 · 安装到 Owlbear 后即可开火。';for(const id of ['lock','aim','fire','cancel'])$<HTMLButtonElement>(id).disabled=true;}
