import OBR from '@owlbear-rodeo/sdk';
import {CHANNEL,SETTINGS,DEFAULT,config,geometry,type Point,type Shot,type Config} from './core';
export type State={shooter:string;name:string;settings:Config;enabled:boolean};
let fallback:State={shooter:'',name:'',settings:DEFAULT,enabled:true};
export function readState():State {
 try{const value=JSON.parse(localStorage.getItem(SETTINGS)||'{}');return {shooter:typeof value.shooter==='string'?value.shooter:'',name:typeof value.name==='string'?value.name:'',settings:config(value.settings),enabled:value.enabled!==false};}catch{return fallback;}
}
export function writeState(state:State){fallback=state;try{localStorage.setItem(SETTINGS,JSON.stringify(state));}catch{throw Error('浏览器禁用了本地存储，请允许此扩展使用存储。');}}
let last=0;
export async function fire(point:Point,target?:string){
 if(performance.now()-last<300)throw Error('请稍等片刻再开火。');
 if(!await OBR.scene.isReady())throw Error('请先打开场景。');
 const state=readState();if(!state.shooter)throw Error('请先选中角色，并点「设为射手」。');
 if(target===state.shooter)throw Error('请选择射手以外的目标。');
 const [shooter]=await OBR.scene.items.getItems([state.shooter]);
 if(!shooter||shooter.type!=='IMAGE'||shooter.layer!=='CHARACTER')throw Error('射手已不存在，请重新设置。');
 if(!shooter.visible)throw Error('请先显示射手 Token，再播放公开特效。');
 if(target){const [item]=await OBR.scene.items.getItems([target]);if(!item||!item.visible)throw Error('目标不可见或已被删除。');point=(await OBR.scene.items.getItemBounds([target])).center;}
 const bounds=await OBR.scene.items.getItemBounds([shooter.id]);
 geometry(bounds.center,point,Math.max(bounds.width,bounds.height),state.settings);
 const packet:Shot={id:crypto.randomUUID(),shooter:shooter.id,target,point,settings:state.settings};
 last=performance.now();await OBR.broadcast.sendMessage(CHANNEL,packet,{destination:'ALL'});
}
