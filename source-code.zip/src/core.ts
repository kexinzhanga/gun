export const NS='com.kexin.gunfire';
export const CHANNEL=NS+'/shot';
export const SETTINGS=NS+'/settings';
export const TOOL=NS+'/tool';
export const MODE=NS+'/aim';
export type Weapon='pistol'|'rifle'|'shotgun';
export type Result='hit'|'miss'|'shield';
export type Point={x:number;y:number};
export type Config={weapon:Weapon;result:Result;color:string;burst:number;thickness:number;spread:number;speed:number;muzzle:number};
export const DEFAULT:Config={weapon:'pistol',result:'hit',color:'#ffc266',burst:1,thickness:2,spread:8,speed:1800,muzzle:70};
const clamp=(n:unknown,min:number,max:number,fallback:number)=>typeof n==='number'&&Number.isFinite(n)?Math.min(max,Math.max(min,n)):fallback;
export function config(raw:unknown):Config {
 const r=(raw&&typeof raw==='object'?raw:{}) as Partial<Config>;
 return {weapon:r.weapon==='rifle'||r.weapon==='shotgun'?r.weapon:'pistol',result:r.result==='miss'||r.result==='shield'?r.result:'hit',color:typeof r.color==='string'&&/^#[0-9a-f]{6}$/i.test(r.color)?r.color:DEFAULT.color,burst:Math.round(clamp(r.burst,1,6,1)),thickness:clamp(r.thickness,1,5,2),spread:clamp(r.spread,0,100,8),speed:clamp(r.speed,600,3000,1800),muzzle:clamp(r.muzzle,0,150,70)};
}
export type Shot={id:string;shooter:string;target?:string;point:Point;settings:Config};
export function validShot(raw:unknown):raw is Shot {
 if(!raw||typeof raw!=='object')return false;const r=raw as Shot;
 return typeof r.id==='string'&&r.id.length<100&&typeof r.shooter==='string'&&(r.target===undefined||typeof r.target==='string')&&!!r.point&&Number.isFinite(r.point.x)&&Number.isFinite(r.point.y)&&Math.abs(r.point.x)<1e7&&Math.abs(r.point.y)<1e7;
}
export function geometry(origin:Point,target:Point,unit:number,c:Config) {
 const dx=target.x-origin.x,dy=target.y-origin.y,d=Math.hypot(dx,dy);
 if(d<5||d>6000)throw Error('请选择距离射手 5–6000 像素的目标。');
 const radius=Math.min(200,Math.max(20,unit/2));
 const offset=Math.min(radius*c.muzzle/100,d*0.35);
 const distance=d-offset;
 const pad=Math.max(70,radius*1.5);
 const spread=(c.weapon==='shotgun'?0.6:0.25)*radius*c.spread/100;
 const miss=c.result==='miss'?radius*1.1:0;
 const height=(pad+spread+miss)*2;
 const start={x:origin.x+dx/d*offset,y:origin.y+dy/d*offset};
 const position={x:start.x-dx/d*pad+dy/d*height/2,y:start.y-dy/d*pad-dx/d*height/2};
 return {width:distance+2*pad,height,position,rotation:Math.atan2(dy,dx)*180/Math.PI,distance,pad,spread,miss,radius,duration:(c.burst-1)*0.13+distance/c.speed+0.65};
}
