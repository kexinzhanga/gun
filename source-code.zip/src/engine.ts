import OBR,{buildEffect,type Item} from '@owlbear-rodeo/sdk';
import {NS,config,validShot,geometry,type Shot} from './core';
import {SHADER} from './shader';
const active=new Map<string,{started:number;duration:number}>();
const seen=new Set<string>();
let updating=false,epoch=0;
export let enabled=true;
export function enable(value:boolean){enabled=value;if(!value)void clear();}
export async function clear(){epoch++;const ids=Array.from(active.keys());active.clear();if(ids.length&&await OBR.scene.isReady())await OBR.scene.local.deleteItems(ids);}
export async function play(raw:unknown) {
 if(!enabled||!validShot(raw)||seen.has(raw.id)||active.size>=4||!await OBR.scene.isReady())return;
 const shot:Shot=raw,stamp=epoch;
 seen.add(shot.id);if(seen.size>200)seen.delete(seen.values().next().value!);
 const items=await OBR.scene.items.getItems([shot.shooter,...(shot.target?[shot.target]:[])]);
 const shooter=items.find(i=>i.id===shot.shooter);
 const target=items.find(i=>i.id===shot.target);
 if(!shooter||!shooter.visible||(shot.target&&(!target||!target.visible)))return;
 const bounds=await OBR.scene.items.getItemBounds([shooter.id]);
 const aim=target?(await OBR.scene.items.getItemBounds([target.id])).center:shot.point;
 const c=config(shot.settings),g=geometry(bounds.center,aim,Math.max(bounds.width,bounds.height),c);
 if(stamp!==epoch||!enabled||active.size>=4)return;
 const rgb=[1,3,5].map(offset=>parseInt(c.color.slice(offset,offset+2),16)/255);
 const effect=buildEffect().name('枪火演出').effectType('STANDALONE')
 .width(g.width).height(g.height).position(g.position).rotation(g.rotation)
 .layer('ATTACHMENT').locked(true).disableHit(true).sksl(SHADER)
 .uniforms([{name:'elapsed',value:0},{name:'rangePx',value:g.distance},{name:'pad',value:g.pad},
 {name:'spread',value:g.spread},{name:'miss',value:g.miss},{name:'radius',value:g.radius},
 {name:'speed',value:c.speed},{name:'burst',value:c.burst},{name:'pellets',value:c.weapon==='shotgun'?7:1},
 {name:'thickness',value:c.thickness},{name:'shield',value:c.result==='shield'?1:0},
 {name:'tint',value:{x:rgb[0],y:rgb[1],z:rgb[2]}}]).metadata({[NS]:true}).build();
 active.set(effect.id,{started:performance.now(),duration:g.duration});
 try {await OBR.scene.local.addItems([effect]);if(stamp!==epoch){await OBR.scene.local.deleteItems([effect.id]);active.delete(effect.id);}}
 catch(error){active.delete(effect.id);throw error;}
}
export function startEngine(){
 setInterval(()=>void tick().catch(console.error),33);
 OBR.scene.onReadyChange(()=>{void clear().catch(console.error);});
}
async function tick(){
 if(updating||!active.size)return;updating=true;
 try {
  if(!await OBR.scene.isReady()){active.clear();return;}
  const now=performance.now(),expired:string[]=[],live:string[]=[];
  for(const [id,a] of active){if((now-a.started)/1000>a.duration){expired.push(id);active.delete(id);}else live.push(id);}
  if(expired.length)await OBR.scene.local.deleteItems(expired);
  if(live.length)await OBR.scene.local.updateItems(live,(items:Item[])=>{
   for(const item of items){const entry=active.get(item.id);if(item.type==='EFFECT'&&entry){
    const uniforms=(item as ReturnType<ReturnType<typeof buildEffect>['build']>).uniforms;
    const elapsed=uniforms.find(u=>u.name==='elapsed');if(elapsed)elapsed.value=(now-entry.started)/1000;
   }}
  });
 }finally{updating=false;}
}
