export const SHADER=`
uniform vec2 size;
uniform float elapsed;
uniform float rangePx;
uniform float pad;
uniform float spread;
uniform float miss;
uniform float radius;
uniform float speed;
uniform float burst;
uniform float pellets;
uniform float thickness;
uniform float shield;
uniform vec3 tint;
float lineDistance(vec2 p,vec2 a,vec2 b) {
 vec2 v=b-a;float f=clamp(dot(p-a,v)/max(dot(v,v),0.001),0.0,1.0);
 return length(p-a-v*f);
}
half4 main(float2 coord) {
 vec2 p=coord-vec2(pad,size.y*0.5);
 float glow=0.0;float blue=0.0;float smoke=0.0;
 for(int i=0;i<6;i++) {
  if(float(i)>=burst)break;
  float t=elapsed-float(i)*0.13;
  if(t<0.0)continue;
  float flash=max(0.0,1.0-t/0.105);
  float muzzle=length(vec2(p.x/1.6,p.y));
  float rays=0.45+0.55*pow(abs(cos(atan(p.y,p.x)*4.0)),5.0);
  glow+=exp(-muzzle/max(radius*0.3,5.0))*flash*rays*2.8;
  for(int j=0;j<7;j++) {
   if(float(j)>=pellets)break;
   float fan=pellets>1.0?(float(j)-3.0)/3.0:sin(float(i)*7.1)*0.5;
   vec2 end=vec2(rangePx,miss+spread*fan);
   float lengthRay=length(end);vec2 dir=end/lengthRay;
   float arrival=lengthRay/speed;
   float head=min(t*speed,lengthRay);
   if(t<arrival) {
    float tail=max(0.0,head-min(120.0,lengthRay*0.25));
    float d=lineDistance(p,dir*tail,dir*head);
    glow+=exp(-d/max(0.8,thickness))*0.95;
    glow+=exp(-length(p-dir*head)/max(1.5,thickness*2.0));
   }
   float age=t-arrival;
   if(age>=0.0&&age<0.55) {
    vec2 hit=p-end;float fade=1.0-age/0.55;
    if(shield>0.5) {
     float ring=abs(length(hit)-(radius*0.4+age*radius*1.4));
     blue+=exp(-ring/2.5)*fade;
     blue+=exp(-length(hit)/max(radius*0.4,8.0))*fade*0.3;
    } else {
     glow+=exp(-length(hit)/max(3.0,10.0-age*18.0))*fade*1.6;
     for(int k=0;k<5;k++) {
      float a=float(k)*2.4+float(j)*0.7+float(i);
      vec2 spark=vec2(cos(a),sin(a))*age*radius*2.2;
      glow+=exp(-lineDistance(hit,spark*0.65,spark)/1.2)*fade*0.75;
     }
     smoke+=exp(-length(hit-vec2(0.0,-age*radius*0.6))/max(5.0,age*radius*0.7))*fade*0.12;
    }
   }
  }
 }
 float alpha=clamp(glow+blue+smoke,0.0,1.0);
 vec3 c=(tint*glow+vec3(0.25,0.8,1.0)*blue+vec3(0.5)*smoke)/max(glow+blue+smoke,0.001);
 c=mix(c,vec3(1.0,0.95,0.8),smoothstep(1.0,3.5,glow)*0.5);
 return half4(c*alpha,alpha);
}`;
