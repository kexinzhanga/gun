import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';import ts from 'typescript';
function load(name,deps={}){const exports={};vm.runInNewContext(ts.transpileModule(fs.readFileSync(new URL('../src/'+name,import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,{exports,require:key=>deps[key],console});return exports;}
const {config,geometry,DEFAULT,validShot}=load('core.ts');
test('untrusted settings clamp animation cost and reject malformed colors',()=>{
 const c=config({weapon:'bad',burst:10000,speed:NaN,spread:-10,color:'<script>',thickness:100});
 assert.equal(c.burst,6);assert.equal(c.speed,1800);assert.equal(c.spread,0);assert.equal(c.color,'#ffc266');assert.equal(c.thickness,5);
 assert.equal(validShot({id:'x',shooter:'x',point:{x:Infinity,y:0}}),false);
 assert.equal(validShot({id:'x',seed:42,shooter:'x',point:{x:10,y:20},settings:DEFAULT}),true);
 assert.equal(config({weapon:'energy'}).weapon,'energy');assert.equal(config({weapon:'rpg'}).weapon,'rpg');
});
test('horizontal, vertical, diagonal rays place muzzle and target correctly',()=>{
 for(const target of [{x:400,y:0},{x:0,y:400},{x:-300,y:400}]){
  const g=geometry({x:0,y:0},target,100,DEFAULT);const angle=g.rotation*Math.PI/180;
  const point={x:g.position.x+Math.cos(angle)*(g.pad+g.distance)-Math.sin(angle)*g.height/2,y:g.position.y+Math.sin(angle)*(g.pad+g.distance)+Math.cos(angle)*g.height/2};
  assert.ok(Math.abs(point.x-target.x)<1e-6);assert.ok(Math.abs(point.y-target.y)<1e-6);
 }
});
test('same point and excessive range fail; miss is offset and shotgun spread is wider',()=>{
 assert.throws(()=>geometry({x:0,y:0},{x:0,y:0},100,DEFAULT));
 assert.throws(()=>geometry({x:0,y:0},{x:8000,y:0},100,DEFAULT));
 const hit=geometry({x:0,y:0},{x:400,y:0},100,DEFAULT);
 const miss=geometry({x:0,y:0},{x:400,y:0},100,{...DEFAULT,result:'miss'});
 const shotgun=geometry({x:0,y:0},{x:400,y:0},100,{...DEFAULT,weapon:'shotgun',spread:70});
 assert.ok(miss.miss>0);assert.equal(hit.miss,0);assert.ok(shotgun.spread>hit.spread);
 const rpg=geometry({x:0,y:0},{x:400,y:0},100,{...DEFAULT,weapon:'rpg'});
 const energy=geometry({x:0,y:0},{x:400,y:0},100,{...DEFAULT,weapon:'energy'});
 assert.equal(rpg.projectileSpeed,900);assert.equal(energy.projectileSpeed,2400);assert.ok(rpg.pad>hit.pad);
});
test('GitHub manifest and bundled page paths all use the correct repository',()=>{
 const manifest=JSON.parse(fs.readFileSync(new URL('../public/manifest.json',import.meta.url),'utf8'));
 for(const path of [manifest.icon,manifest.action.icon,manifest.action.popover,manifest.background_url])assert.ok(path.startsWith('https://kexinzhanga.github.io/gun/'));
});
